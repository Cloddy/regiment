# Содержание

- [Использование](#usage)
- [Отмена запроса](#cancel-request)
- [Особенности использования при SSR](#usage-ssr)

# <a name="usage">Использование</a>

### 1) Создайте в своем проекте Singleton-класс ApiStore

Создайте класс в папке со всеми сторами. Этот стор лучше сделать глобальным

```javascript
// В вашем проекте: @/stores/ApiStore.ts
import { ApiStore } from '@kts-front/call-api';

// Если у вас на проекте клиентский рендеринг, указывать baseUrl необязательно
// Памятка о том, как корректно указать baseUrl при SSR, будет ниже
const apiStore = new ApiStore({ baseUrl: '/' });
```

### 2) Используйте apiStore для создания экземпляра запроса

Поскольку запрос содержит возможность сделать отмену, а также meta, то создавать экземпляр рекомендуется в конструкторе стора, а не в момент вызова. Для того, чтобы meta можно было эффективно использовать.

```javascript
import { apiStore } from "@/stores/ApiStore";

class SomeRandomClass {
    ...
    private _myRequest = apiStore.createRequest<ResponseType>({
        url: '/some-endpoint',
        method: 'GET'
    });
    ...
}
```

### 3) Используйте экземпляр запроса для его вызова

```javascript
class SomeRandomClass {
    ...
    async load() {
        // при необходимости передайте объект с параметрами.
        // Например, data для POST-запроса
        // или params для GET-запроса
            const response = this._myRequest.call(someParams)
        }
    ...
}
```

# <a name="cancel-request">Авторизация</a>

Доступные схемы авторизации:
- Bearer

```javascript
const apiStore = new ApiStore({
  getAuthorizationCallback: () => {
      const token = localStorage.getItem('token');

      if (token) {
        return {
          scheme: HttpAuthorizationScheme.Bearer,
          data: token
        }
      }

      return null;
  }
})
```

# <a name="cancel-request">Мок ответа от сервера</a>

```javascript
class SomeRandomClass {
    ...
    async load() {
            // также можно имитировать лоадинг, передав параметр timeout
            const response = this._myRequest.call({
              mockResponse: {
                  isError: false,
                  data: {},
                  timeout: 2000
              }
            })
        }
    ...
}
```

# <a name="cancel-request">Отмена запроса</a>

### 1) Возможность отменить запрос

По умолчанию запрос отменяется при срабатывании метода .destroy() у экземпляра запроса. Иногда при разрушении стора запроса отменять запрос не нужно: например, вы кликнули на кнопку "Заказа" и ушли со страницы

```javascript
import { apiStore } from "@/stores/ApiStore";

class SomeRandomClass {
     private _myRequest = apiStore.createRequest<ResponseType>({
        url: '/some-endpoint',
        method: 'GET'
    });

    async load() {
        this._myRequest.cancel();

        const response = this._myRequest.call(someParams);

        if (response.isCancelled) {
            return
        }

        if (response.isError) {
            this._snackBarStore.sendError('Ошибка');
            return;
        }

        this._snackBarStore.sendSuccess('Успех');

    }
}
```

### 2) Поведение по умолчанию

По-умолчанию запрос отменяется при вызове .destroy(). Иногда при разрушении стора запрос отменять не нужно: например, вы создали заказ и перешли на другю страницу.

Чтобы эту логику переопределить, передайте в конструктор запроса параметр cancelOnDestroy = false

```javascript
 private _myRequest = apiStore.createRequest<ResponseType>({
        url: '/some-endpoint',
        method: 'GET',
        cancelOnDestroy: false
    });
```

# <a name="usage-ssr">Особенности использования при SSR</a>

### 1) Создайте в своем проекте Singleton-класс ApiStore

```javascript
// В случае с SSR запрос выполняется с сервера, поэтому baseUrl должен содержать абсолютный путь бэкенда (домен, адрес сервера и т.д.) в формате https://base-url.ru/api/some-endpoint/
const apiStore = new ApiStore({ baseUrl: 'https://cms.rsv-test.bizml.ru' });
```

### 2) Совпадает с пунктом 2 в разделе "Использование"

### 3) Используйте экземпляр запроса для его вызова

– Если запрос происходит на клиенте, что он выполняется точно так же как и при клиентском рендеринге
– Если запрос происходит на сервере, обязательно прокиньте ApiContext. При использовании Next.js, ApiContext можно взять из функций getServerSideProps / getStaticProps. Чтобы не создавать классы на сервере, хорошей практикой будет вызов запроса внутри статического метода у класса

`SomePage.jsx`

```js
const SomePage = (props) => {
    return <div>Content {props.data}</div>
}
export const getServerSideProps: GetServerSideProps<any, any> = async ({ locale, req, res }) => {
    const data = await SomeRandomClass.initialize({ req, res })

    return {
        props: {
            data
        }
    }
}
```

`SomeClass.js`

```javascript
import { ApiContext } from "@kts-libs/types";

class SomeRandomClass {
    ...
    static initialize(apiContext: ApiContext) {
            const response = this._myRequest.call({ ...someParams, apiContext })
            ...
            return response
        }
    ...
}
```
